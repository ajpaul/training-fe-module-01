/**
 * Controllers
 * @module controllers
 */
define(function (require, exports, module) {

    'use strict';

    /**
     * Main controller
     * @ngInject
     * @constructor
     */
    function MainCtrl() {
        var ctrl = this;
    }

    MainCtrl.prototype.$onInit = function() {
        // Do initialization here
    };

    module.exports = MainCtrl;
});
