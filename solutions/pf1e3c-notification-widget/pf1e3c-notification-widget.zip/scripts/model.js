/**
 * Models
 * @module models
 */
define( function (require, exports, module) {

    'use strict';

    /**
     * @constructor
     * @ngInject
     */
    function WidgetModel(lpWidget, lpCoreUtils) {
        
    }

    module.exports = WidgetModel;
});
